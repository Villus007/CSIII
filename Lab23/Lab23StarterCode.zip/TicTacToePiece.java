public enum TicTacToePiece
{
  X,  O;
}
